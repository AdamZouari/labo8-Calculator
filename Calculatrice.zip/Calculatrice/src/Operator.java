abstract class Operator
{
  abstract void execute();
  protected State state;

}
